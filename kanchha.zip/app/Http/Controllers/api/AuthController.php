<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Vonage\Client;
use Vonage\Client\Credentials\Basic;
use Vonage\SMS\Message\SMS;

class AuthController extends Controller
{
    // Generate Token
    private function getResponse(User $user) {
        Auth::login($user);

        //Create token after registering user
        $tokenResult = $user->createToken("Personal Access Token");

        $token = $tokenResult->token;
        $token->expires_at = Carbon::now()->addWeeks(1);
        $token->save();

        return response([
            'accessToken' => $tokenResult->accessToken,
            'tokenType' => "Bearer",
            'expiresAt' => Carbon::parse($token->expires_at)->toDateTimeString()
        ], 200);
    }

    // Login User with Phone Number and send otp
    public function login(Request $request) {
        $validator = Validator::make($request->all(), [
            "phoneNumber" => "required"
        ]);

        if ($validator->fails())
        {
            return response(['errors' => $validator->errors()], 422);
        }

        $otp = rand(10000,99999);
        $user = User::where('phone_number','=',$request->phoneNumber)->first();

        if ($user == null) {
            return response(['error' => "User doesn't exits!"], 401);
        }

        $user->otp = $otp;
        $user->save();

        // Sending OTP to user number
        $basic  = new Basic("797a72af", "DytDVgkbn8Qo2Jh3");
        $client = new Client($basic);
        $response = $client->sms()->send(
            new SMS("923480984422", "Kanchha", 'Otp code: ' . $otp)
        );
        $message = $response->current();

        if ($message->getStatus() == 0) {
            return response($user, 200);
        } else {
            return response($message->getStatus(), 401);
        }
    }

    // Register User with Phone Number and send otp
    public function register(Request $request) {
        $validator = Validator::make($request->all(), [
            "phoneNumber" => "required"
        ]);

        if ($validator->fails())
        {
            return response(['errors' => $validator->errors()], 422);
        }

        $otp = rand(10000,99999);
        $user = new User();
        $user->phone_number = $request->phoneNumber;
        $user->otp = $otp;
        $user->save();

        // Sending OTP to user number
        $basic  = new Basic("797a72af", "DytDVgkbn8Qo2Jh3");
        $client = new Client($basic);
        $response = $client->sms()->send(
            new SMS("923480984422", "Kanchha", 'Otp code: ' . $otp)
        );
        $message = $response->current();

        if ($message->getStatus() == 0) {
            return response($user, 200);
        } else {
            return response($message->getStatus(), 401);
        }
    }

    // Verify OTP from user
    public function verifyOtp(Request $request) {
        $validator = Validator::make($request->all(), [
            "phoneNumber" => "required",
            "otp" => "required|min:5"
        ]);

        if ($validator->fails())
        {
            return response(['errors' => $validator->errors()], 422);
        }

        $user = User::where('phone_number','=',$request->phoneNumber)->where('otp', '=', $request->otp)->first();

        if ($user == null) {
            return response(['error' => "Wrong OTP!"], 401);
        }

        // Create token after registering user
        return $this->getResponse($user);
    }

    // Resend OTP to user
    public function resendOtp(Request $request) {
        $validator = Validator::make($request->all(), [
            "phoneNumber" => "required"
        ]);

        if ($validator->fails())
        {
            return response(['errors' => $validator->errors()], 422);
        }

        $otp = rand(10000,99999);
        $user = User::where('phone_number','=',$request->phoneNumber)->first();
        $user->otp = $otp;
        $user->save();

        // Sending OTP to user number
        $basic  = new Basic("797a72af", "DytDVgkbn8Qo2Jh3");
        $client = new Client($basic);
        $response = $client->sms()->send(
            new SMS("923480984422", "Kanchha", 'Otp code: ' . $otp)
        );
        $message = $response->current();

        if ($message->getStatus() == 0) {
            return response($user, 200);
        } else {
            return response($message->getStatus(), 401);
        }
    }

    //logout
    public function logout(Request $request){
        return $request->user()->token()->revoke();
    }

    //get userData
    public function user(Request $request){
        return $request->user();
    }

    //authenticate user
    public function authFailed(){
        return response('unauthenticated', 401);
    }
}
